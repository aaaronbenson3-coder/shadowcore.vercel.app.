export const SUBJECTS = [
  "mathematics",
  "english",
  "physics",
  "chemistry",
  "biology",
  "economics",
  "government",
  "literature",
  "general",
] as const;

export type Subject = (typeof SUBJECTS)[number];

export const SOURCE_TYPES = [
  "past-questions",
  "notes",
  "videos",
  "practice",
  "syllabus",
  "textbooks",
] as const;

export type SourceType = (typeof SOURCE_TYPES)[number];

export interface Extension {
  id: string;
  name: string;
  url: string;
  description: string;
  type: SourceType;
  subjects: Subject[];
  enabled: boolean;
  pinned: boolean;
  order: number;
  builtIn: boolean;
}

export interface StudyTab {
  id: string;
  extensionId: string;
  url: string;
  title: string;
  pinned: boolean;
}

export interface Favorite {
  id: string;
  title: string;
  url: string;
  extensionId?: string;
  createdAt: number;
}

export interface Note {
  id: string;
  title: string;
  body: string;
  updatedAt: number;
}

export type ThemeMode = "light" | "dark" | "system";

export interface HubExport {
  version: 1;
  exportedAt: string;
  extensions: Extension[];
  favorites: Favorite[];
  notes: Note[];
  examDate: string;
  dailyGoalMinutes: number;
  pomodoroMinutes: number;
  breakMinutes: number;
  theme: ThemeMode;
}

export const SUBJECT_LABEL: Record<Subject, string> = {
  mathematics: "Mathematics",
  english: "English",
  physics: "Physics",
  chemistry: "Chemistry",
  biology: "Biology",
  economics: "Economics",
  government: "Government",
  literature: "Literature",
  general: "General",
};

export const TYPE_LABEL: Record<SourceType, string> = {
  "past-questions": "Past Questions",
  notes: "Notes",
  videos: "Videos",
  practice: "Practice",
  syllabus: "Syllabus",
  textbooks: "Textbooks",
};
