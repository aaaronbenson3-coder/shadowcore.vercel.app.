/**
 * Helpers for the in-app browser. Many study sites set X-Frame-Options and
 * will refuse to render inside an iframe — the workspace UI handles that
 * with a fallback. YouTube watch URLs are rewritten to embed URLs so they
 * actually play inside the panel.
 */
export function toEmbedUrl(raw: string): string {
  try {
    const u = new URL(raw);
    const host = u.hostname.replace(/^www\./, "");

    if (host === "youtu.be") {
      const id = u.pathname.replace("/", "");
      if (id) return `https://www.youtube-nocookie.com/embed/${id}`;
    }

    if (host === "youtube.com" || host === "m.youtube.com" || host === "youtube-nocookie.com") {
      if (u.pathname.startsWith("/embed")) {
        u.hostname = "www.youtube-nocookie.com";
        return u.toString();
      }
      const video = u.searchParams.get("v");
      if (video) return `https://www.youtube-nocookie.com/embed/${video}`;
      const list = u.searchParams.get("list");
      if (list) {
        return `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(list)}`;
      }
      if (u.pathname.startsWith("/results")) {
        const q = u.searchParams.get("search_query") ?? "";
        return `https://www.youtube-nocookie.com/embed?listType=search&list=${encodeURIComponent(q)}`;
      }
      if (u.pathname.startsWith("/playlist")) {
        const pl = u.searchParams.get("list");
        if (pl) {
          return `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(pl)}`;
        }
      }
    }

    return raw;
  } catch {
    return raw;
  }
}

export const IFRAME_ALLOW =
  "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen; web-share";

export const IFRAME_SANDBOX =
  "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals allow-presentation";
