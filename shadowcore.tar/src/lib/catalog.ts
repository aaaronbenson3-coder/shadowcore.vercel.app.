/**
 * Default WASCE / WASSCE study sources.
 *
 * HOW TO ADD MORE EXTENSIONS LATER
 * --------------------------------
 * 1. In-app (recommended): open Sources → “Add source”, enter a name and URL.
 *    Optional: pick a type (Past Questions, Notes, Videos…) and a subject.
 *    Everything is saved in localStorage and can be exported as JSON.
 *
 * 2. In this file (ships with the app for every new student):
 *    Push another object onto DEFAULT_EXTENSIONS with:
 *      id          unique slug, e.g. "mysite-biology"
 *      name        short card title
 *      url         full https URL (a hub page, or a deep link to one topic)
 *      description one-line what the student will find there
 *      type        "past-questions" | "notes" | "videos" | "practice"
 *                  | "syllabus" | "textbooks"
 *      subjects    subset of mathematics, english, physics, chemistry,
 *                  biology, economics, government, literature, general
 *      enabled     true to show it on the home grid
 *      pinned      true to pin it in the sidebar
 *      order       sort key, lower first
 *      builtIn     true so Settings → Restore catalog can bring it back
 *
 * Deep links are first-class: a card can point at “Math Past Questions
 * 2015–2024” instead of a whole site. YouTube watch/playlist URLs are
 * rewritten to embed URLs automatically when opened in the study panel.
 *
 * Existing installs pick up newly added built-ins on the next load without
 * wiping custom sources (see mergeMissingBuiltins).
 */
import type { Extension } from "./types";

export const DEFAULT_EXTENSIONS: Extension[] = [
  {
    id: "waec-elearning",
    name: "WAEC e-Learning",
    url: "https://www.waeconline.org.ng/e-Learning/index.htm",
    description: "Official WAEC past questions, marking schemes, and chief examiners’ reports.",
    type: "past-questions",
    subjects: ["general"],
    enabled: true,
    pinned: true,
    order: 10,
    builtIn: true,
  },
  {
    id: "myschoolgist-waec",
    name: "WAEC Past Questions",
    url: "https://www.myschoolgist.com/ng/waec-past-questions/",
    description: "Downloadable WAEC / WASSCE papers across subjects and years.",
    type: "past-questions",
    subjects: ["general"],
    enabled: true,
    pinned: true,
    order: 20,
    builtIn: true,
  },
  {
    id: "myschoolgist-math",
    name: "Mathematics Past Questions",
    url: "https://www.myschoolgist.com/ng/waec-mathematics-past-questions/",
    description: "WAEC Mathematics papers and solutions, 2015 onward.",
    type: "past-questions",
    subjects: ["mathematics"],
    enabled: true,
    pinned: false,
    order: 30,
    builtIn: true,
  },
  {
    id: "myschoolgist-english",
    name: "English Language Past Questions",
    url: "https://www.myschoolgist.com/ng/waec-english-language-past-questions/",
    description: "Paper 1–3 English Language past questions with suggested answers.",
    type: "past-questions",
    subjects: ["english"],
    enabled: true,
    pinned: false,
    order: 40,
    builtIn: true,
  },
  {
    id: "passnownow",
    name: "Passnownow Notes",
    url: "https://www.passnownow.com/",
    description: "Class notes and lesson summaries written for Nigerian SS students.",
    type: "notes",
    subjects: ["general"],
    enabled: true,
    pinned: true,
    order: 50,
    builtIn: true,
  },
  {
    id: "khan-academy",
    name: "Khan Academy",
    url: "https://www.khanacademy.org/",
    description: "Free video lessons and practice for maths and the sciences.",
    type: "videos",
    subjects: ["mathematics", "physics", "chemistry", "biology", "economics"],
    enabled: true,
    pinned: true,
    order: 60,
    builtIn: true,
  },
  {
    id: "openstax",
    name: "OpenStax Textbooks",
    url: "https://openstax.org/subjects",
    description: "Peer-reviewed open textbooks for maths, science, and social science.",
    type: "textbooks",
    subjects: ["mathematics", "physics", "chemistry", "biology", "economics"],
    enabled: true,
    pinned: false,
    order: 70,
    builtIn: true,
  },
  {
    id: "physics-classroom",
    name: "The Physics Classroom",
    url: "https://www.physicsclassroom.com/",
    description: "Clear tutorials, diagrams, and concept-builders for SS physics.",
    type: "notes",
    subjects: ["physics"],
    enabled: true,
    pinned: false,
    order: 80,
    builtIn: true,
  },
  {
    id: "chem-libretexts",
    name: "Chemistry LibreTexts",
    url: "https://chem.libretexts.org/",
    description: "Open chemistry library covering organic, physical, and practical work.",
    type: "textbooks",
    subjects: ["chemistry"],
    enabled: true,
    pinned: false,
    order: 90,
    builtIn: true,
  },
  {
    id: "ck12",
    name: "CK-12 Practice",
    url: "https://www.ck12.org/",
    description: "Adaptive practice and flexbooks for maths and science drills.",
    type: "practice",
    subjects: ["mathematics", "physics", "chemistry", "biology"],
    enabled: true,
    pinned: false,
    order: 100,
    builtIn: true,
  },
  {
    id: "youtube-wassce",
    name: "YouTube WASSCE Prep",
    url: "https://www.youtube.com/results?search_query=WASSCE+past+questions+worked+solutions",
    description: "Worked solutions and revision videos for core WASSCE papers.",
    type: "videos",
    subjects: ["general"],
    enabled: true,
    pinned: false,
    order: 110,
    builtIn: true,
  },
  {
    id: "gutenberg-lit",
    name: "Project Gutenberg",
    url: "https://www.gutenberg.org/",
    description: "Public-domain novels and drama for Literature-in-English reading.",
    type: "textbooks",
    subjects: ["literature", "english"],
    enabled: true,
    pinned: false,
    order: 120,
    builtIn: true,
  },
];

/** Typical WASSCE start — first week of May. Change the year in Settings. */
export const DEFAULT_EXAM_DATE = "2027-05-03";

export function mergeMissingBuiltins(saved: Extension[]): Extension[] {
  const list = saved.length ? saved : DEFAULT_EXTENSIONS;
  const ids = new Set(list.map((e) => e.id));
  const missing = DEFAULT_EXTENSIONS.filter((e) => !ids.has(e.id));
  if (missing.length === 0) return list;
  const maxOrder = list.reduce((m, e) => Math.max(m, e.order), 0);
  return [
    ...list,
    ...missing.map((e, i) => ({ ...e, order: maxOrder + (i + 1) * 10 })),
  ];
}
