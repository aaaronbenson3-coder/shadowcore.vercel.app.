import { useEffect, useState } from "react";

export function useIsMobile(query = "(max-width: 767px)") {
  const [mobile, setMobile] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia(query);
    const apply = () => setMobile(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [query]);

  return mobile;
}
