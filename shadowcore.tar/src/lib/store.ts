import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { DEFAULT_EXAM_DATE, DEFAULT_EXTENSIONS, mergeMissingBuiltins } from "./catalog";
import { toEmbedUrl } from "./embed";
import type {
  Extension,
  Favorite,
  HubExport,
  Note,
  SourceType,
  Subject,
  StudyTab,
  ThemeMode,
} from "./types";
import { todayKey, uid } from "./utils";

interface HubState {
  extensions: Extension[];
  tabs: StudyTab[];
  activeTabId: string | null;
  splitTabId: string | null;
  favorites: Favorite[];
  notes: Note[];
  activeNoteId: string | null;
  recentIds: string[];
  theme: ThemeMode;
  examDate: string;
  dailyGoalMinutes: number;
  studiedMinutes: number;
  studiedDate: string;
  pomodoroMinutes: number;
  breakMinutes: number;
  notesPanelOpen: boolean;
  focusMode: boolean;
  hydrated: boolean;
  addExtension: (input: {
    name: string;
    url: string;
    description?: string;
    type?: SourceType;
    subjects?: Subject[];
  }) => string;
  updateExtension: (id: string, patch: Partial<Extension>) => void;
  removeExtension: (id: string) => void;
  moveExtension: (id: string, direction: "up" | "down") => void;
  restoreCatalog: () => void;
  openExtension: (id: string, opts?: { newTab?: boolean; url?: string }) => string | null;
  closeTab: (id: string) => void;
  setActiveTab: (id: string) => void;
  updateTab: (id: string, patch: Partial<StudyTab>) => void;
  toggleTabPin: (id: string) => void;
  toggleSplit: (id?: string) => void;
  addFavorite: (input: { title: string; url: string; extensionId?: string }) => void;
  removeFavorite: (id: string) => void;
  upsertNote: (note: Partial<Note> & { id?: string }) => string;
  removeNote: (id: string) => void;
  setActiveNote: (id: string | null) => void;
  setTheme: (theme: ThemeMode) => void;
  setExamDate: (iso: string) => void;
  setDailyGoal: (minutes: number) => void;
  logStudyMinutes: (minutes: number) => void;
  setPomodoroMinutes: (minutes: number) => void;
  setBreakMinutes: (minutes: number) => void;
  setNotesPanelOpen: (open: boolean) => void;
  setFocusMode: (on: boolean) => void;
  markHydrated: () => void;
  exportData: () => HubExport;
  importData: (data: HubExport) => void;
}

function sorted(list: Extension[]): Extension[] {
  return [...list].sort((a, b) => a.order - b.order || a.name.localeCompare(b.name));
}

function rollStudyDay(
  studiedDate: string,
  studiedMinutes: number,
): { studiedDate: string; studiedMinutes: number } {
  const today = todayKey();
  if (studiedDate === today) return { studiedDate, studiedMinutes };
  return { studiedDate: today, studiedMinutes: 0 };
}

export const useHub = create<HubState>()(
  persist(
    (set, get) => ({
      extensions: DEFAULT_EXTENSIONS,
      tabs: [],
      activeTabId: null,
      splitTabId: null,
      favorites: [],
      notes: [],
      activeNoteId: null,
      recentIds: [],
      theme: "system",
      examDate: DEFAULT_EXAM_DATE,
      dailyGoalMinutes: 60,
      studiedMinutes: 0,
      studiedDate: todayKey(),
      pomodoroMinutes: 25,
      breakMinutes: 5,
      notesPanelOpen: false,
      focusMode: false,
      hydrated: false,

      addExtension: (input) => {
        const id = uid("src");
        const maxOrder = get().extensions.reduce((m, e) => Math.max(m, e.order), 0);
        const ext: Extension = {
          id,
          name: input.name.trim(),
          url: input.url.trim(),
          description: (input.description ?? "").trim() || "Custom study source",
          type: input.type ?? "notes",
          subjects: input.subjects?.length ? input.subjects : ["general"],
          enabled: true,
          pinned: false,
          order: maxOrder + 10,
          builtIn: false,
        };
        set({ extensions: [...get().extensions, ext] });
        return id;
      },

      updateExtension: (id, patch) => {
        set({
          extensions: get().extensions.map((e) => (e.id === id ? { ...e, ...patch, id: e.id } : e)),
        });
      },

      removeExtension: (id) => {
        const { tabs, activeTabId, splitTabId } = get();
        const nextTabs = tabs.filter((t) => t.extensionId !== id);
        set({
          extensions: get().extensions.filter((e) => e.id !== id),
          tabs: nextTabs,
          activeTabId:
            activeTabId && nextTabs.some((t) => t.id === activeTabId)
              ? activeTabId
              : (nextTabs[0]?.id ?? null),
          splitTabId: splitTabId && nextTabs.some((t) => t.id === splitTabId) ? splitTabId : null,
          recentIds: get().recentIds.filter((x) => x !== id),
        });
      },

      moveExtension: (id, direction) => {
        const list = sorted(get().extensions);
        const i = list.findIndex((e) => e.id === id);
        if (i < 0) return;
        const j = direction === "up" ? i - 1 : i + 1;
        if (j < 0 || j >= list.length) return;
        const a = list[i];
        const b = list[j];
        if (!a || !b) return;
        const next = list.map((e) => {
          if (e.id === a.id) return { ...e, order: b.order };
          if (e.id === b.id) return { ...e, order: a.order };
          return e;
        });
        set({ extensions: next });
      },

      restoreCatalog: () => {
        const custom = get().extensions.filter((e) => !e.builtIn);
        const keptIds = new Set(custom.map((e) => e.id));
        const maxCustom = custom.reduce((m, e) => Math.max(m, e.order), 0);
        const builtins = DEFAULT_EXTENSIONS.map((e, i) => ({
          ...e,
          order: maxCustom + (i + 1) * 10,
        }));
        set({
          extensions: [...builtins, ...custom],
          recentIds: get().recentIds.filter(
            (id) => keptIds.has(id) || DEFAULT_EXTENSIONS.some((e) => e.id === id),
          ),
        });
      },

      openExtension: (id, opts) => {
        const ext = get().extensions.find((e) => e.id === id);
        if (!ext || !ext.enabled) return null;
        const url = toEmbedUrl(opts?.url ?? ext.url);
        const existing = opts?.newTab
          ? undefined
          : get().tabs.find((t) => t.extensionId === id && t.url === url);
        if (existing) {
          set({
            activeTabId: existing.id,
            recentIds: [id, ...get().recentIds.filter((x) => x !== id)].slice(0, 12),
          });
          return existing.id;
        }
        const tab: StudyTab = {
          id: uid("tab"),
          extensionId: id,
          url,
          title: ext.name,
          pinned: false,
        };
        set({
          tabs: [...get().tabs, tab],
          activeTabId: tab.id,
          recentIds: [id, ...get().recentIds.filter((x) => x !== id)].slice(0, 12),
        });
        return tab.id;
      },

      closeTab: (id) => {
        const { tabs, activeTabId, splitTabId } = get();
        const i = tabs.findIndex((t) => t.id === id);
        const next = tabs.filter((t) => t.id !== id);
        let nextActive = activeTabId;
        if (activeTabId === id) {
          nextActive = (tabs[i + 1] ?? tabs[i - 1])?.id ?? null;
        }
        set({
          tabs: next,
          activeTabId: nextActive,
          splitTabId: splitTabId === id ? null : splitTabId,
        });
      },

      setActiveTab: (id) => set({ activeTabId: id }),

      updateTab: (id, patch) => {
        set({
          tabs: get().tabs.map((t) => (t.id === id ? { ...t, ...patch } : t)),
        });
      },

      toggleTabPin: (id) => {
        set({
          tabs: get().tabs.map((t) => (t.id === id ? { ...t, pinned: !t.pinned } : t)),
        });
      },

      toggleSplit: (id) => {
        const { splitTabId, activeTabId, tabs } = get();
        if (splitTabId) {
          set({ splitTabId: null });
          return;
        }
        const other = tabs.find((t) => t.id !== (id ?? activeTabId));
        set({ splitTabId: other?.id ?? null });
      },

      addFavorite: (input) => {
        const exists = get().favorites.some((f) => f.url === input.url);
        if (exists) return;
        const fav: Favorite = {
          id: uid("fav"),
          title: input.title,
          url: input.url,
          extensionId: input.extensionId,
          createdAt: Date.now(),
        };
        set({ favorites: [fav, ...get().favorites] });
      },

      removeFavorite: (id) => {
        set({ favorites: get().favorites.filter((f) => f.id !== id) });
      },

      upsertNote: (note) => {
        const now = Date.now();
        if (note.id) {
          set({
            notes: get().notes.map((n) =>
              n.id === note.id
                ? {
                    ...n,
                    title: note.title ?? n.title,
                    body: note.body ?? n.body,
                    updatedAt: now,
                  }
                : n,
            ),
            activeNoteId: note.id,
          });
          return note.id;
        }
        const created: Note = {
          id: uid("note"),
          title: note.title ?? "Untitled note",
          body: note.body ?? "",
          updatedAt: now,
        };
        set({ notes: [created, ...get().notes], activeNoteId: created.id });
        return created.id;
      },

      removeNote: (id) => {
        const notes = get().notes.filter((n) => n.id !== id);
        set({
          notes,
          activeNoteId: get().activeNoteId === id ? (notes[0]?.id ?? null) : get().activeNoteId,
        });
      },

      setActiveNote: (id) => set({ activeNoteId: id }),
      setTheme: (theme) => set({ theme }),
      setExamDate: (iso) => set({ examDate: iso }),
      setDailyGoal: (minutes) => set({ dailyGoalMinutes: Math.max(15, Math.min(360, minutes)) }),

      logStudyMinutes: (minutes) => {
        const rolled = rollStudyDay(get().studiedDate, get().studiedMinutes);
        set({
          studiedDate: rolled.studiedDate,
          studiedMinutes: rolled.studiedMinutes + Math.max(0, minutes),
        });
      },

      setPomodoroMinutes: (minutes) => set({ pomodoroMinutes: minutes }),
      setBreakMinutes: (minutes) => set({ breakMinutes: minutes }),
      setNotesPanelOpen: (open) => set({ notesPanelOpen: open }),
      setFocusMode: (on) => set({ focusMode: on }),
      markHydrated: () => set({ hydrated: true }),

      exportData: () => {
        const s = get();
        return {
          version: 1,
          exportedAt: new Date().toISOString(),
          extensions: s.extensions,
          favorites: s.favorites,
          notes: s.notes,
          examDate: s.examDate,
          dailyGoalMinutes: s.dailyGoalMinutes,
          pomodoroMinutes: s.pomodoroMinutes,
          breakMinutes: s.breakMinutes,
          theme: s.theme,
        };
      },

      importData: (data) => {
        if (!data || data.version !== 1 || !Array.isArray(data.extensions)) return;
        set({
          extensions: mergeMissingBuiltins(data.extensions),
          favorites: Array.isArray(data.favorites) ? data.favorites : [],
          notes: Array.isArray(data.notes) ? data.notes : [],
          examDate: data.examDate || get().examDate,
          dailyGoalMinutes: data.dailyGoalMinutes || get().dailyGoalMinutes,
          pomodoroMinutes: data.pomodoroMinutes || get().pomodoroMinutes,
          breakMinutes: data.breakMinutes || get().breakMinutes,
          theme: data.theme || get().theme,
        });
      },
    }),
    {
      name: "wasce-hub",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        extensions: state.extensions,
        tabs: state.tabs,
        activeTabId: state.activeTabId,
        splitTabId: state.splitTabId,
        favorites: state.favorites,
        notes: state.notes,
        activeNoteId: state.activeNoteId,
        recentIds: state.recentIds,
        theme: state.theme,
        examDate: state.examDate,
        dailyGoalMinutes: state.dailyGoalMinutes,
        studiedMinutes: state.studiedMinutes,
        studiedDate: state.studiedDate,
        pomodoroMinutes: state.pomodoroMinutes,
        breakMinutes: state.breakMinutes,
        notesPanelOpen: state.notesPanelOpen,
      }),
    },
  ),
);

export function applyTheme(theme: ThemeMode) {
  if (typeof document === "undefined") return;
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const dark = theme === "dark" || (theme === "system" && prefersDark);
  document.documentElement.classList.toggle("dark", dark);
  document.documentElement.style.colorScheme = dark ? "dark" : "light";
  localStorage.setItem("wasce-hub-theme", theme);
}
