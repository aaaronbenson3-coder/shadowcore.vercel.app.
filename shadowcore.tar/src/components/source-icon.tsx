import { useState } from "react";
import { cn, faviconUrl } from "@/lib/utils";

export function SourceIcon({
  url,
  name,
  className,
  imgClassName,
}: {
  url: string;
  name: string;
  className?: string;
  imgClassName?: string;
}) {
  const [failed, setFailed] = useState(false);
  const letter = name.trim().charAt(0).toUpperCase() || "S";

  return (
    <span
      className={cn(
        "flex size-11 shrink-0 items-center justify-center overflow-hidden rounded-md bg-accent text-accent-foreground",
        className,
      )}
      aria-hidden
    >
      {failed ? (
        <span className="font-display text-sm font-semibold">{letter}</span>
      ) : (
        <img
          src={faviconUrl(url)}
          alt=""
          width={22}
          height={22}
          className={cn("size-[22px]", imgClassName)}
          onError={() => setFailed(true)}
        />
      )}
    </span>
  );
}
