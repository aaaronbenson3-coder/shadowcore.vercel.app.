import { useNavigate } from "@tanstack/react-router";
import {
  ArrowDown,
  ArrowUp,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  MoreHorizontal,
  Pin,
  PinOff,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { SourceIcon } from "@/components/source-icon";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Switch } from "@/components/ui/switch";
import { useHub } from "@/lib/store";
import { TYPE_LABEL, type Extension } from "@/lib/types";
import { cn, hostnameOf } from "@/lib/utils";

export function SourceCard({
  source,
  compact = false,
}: {
  source: Extension;
  compact?: boolean;
}) {
  const navigate = useNavigate();
  const updateExtension = useHub((s) => s.updateExtension);
  const removeExtension = useHub((s) => s.removeExtension);
  const moveExtension = useHub((s) => s.moveExtension);
  const openExtension = useHub((s) => s.openExtension);
  const [confirm, setConfirm] = useState(false);

  function open(newTab = false) {
    if (!source.enabled) {
      toast.message("Enable this source first.");
      return;
    }
    openExtension(source.id, { newTab });
    void navigate({ to: "/study" });
  }

  return (
    <>
      <article
        className={cn(
          "group relative flex flex-col rounded-2xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150",
          "hover:shadow-[var(--shadow-border-hover)]",
          !source.enabled && "opacity-60",
          compact && "p-3",
        )}
      >
        <div className="mb-3 flex items-start gap-3">
          <button type="button" onClick={() => open()} aria-label={`Open ${source.name}`}>
            <SourceIcon url={source.url} name={source.name} />
          </button>
          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-2">
              <button type="button" onClick={() => open()} className="min-w-0 text-left">
                <h3 className="truncate font-medium tracking-tight text-card-foreground">{source.name}</h3>
                <p className="truncate text-xs text-muted-foreground">{hostnameOf(source.url)}</p>
              </button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon-sm" variant="ghost" aria-label="Source actions">
                    <MoreHorizontal />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onSelect={() => open(true)}>Open in new panel</DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => window.open(source.url, "_blank", "noopener")}>
                    <ExternalLink /> Open outside
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => updateExtension(source.id, { pinned: !source.pinned })}
                  >
                    {source.pinned ? <PinOff /> : <Pin />}
                    {source.pinned ? "Unpin" : "Pin"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => moveExtension(source.id, "up")}>
                    <ArrowUp /> Move up
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => moveExtension(source.id, "down")}>
                    <ArrowDown /> Move down
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => setConfirm(true)}>
                    <Trash2 /> Remove
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        {!compact ? (
          <p className="mb-4 line-clamp-2 flex-1 text-sm text-muted-foreground">{source.description}</p>
        ) : null}
        <div className="mt-auto flex items-center gap-2">
          <Badge className="bg-muted text-muted-foreground">{TYPE_LABEL[source.type]}</Badge>
          {source.pinned ? (
            <BookmarkCheck className="size-3.5 text-primary" aria-label="Pinned" />
          ) : (
            <Bookmark className="size-3.5 text-transparent group-hover:text-muted-foreground" />
          )}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs text-muted-foreground">On</span>
            <Switch
              checked={source.enabled}
              onCheckedChange={(v) => updateExtension(source.id, { enabled: v })}
              aria-label={`Enable ${source.name}`}
            />
          </div>
        </div>
      </article>

      <AlertDialog open={confirm} onOpenChange={setConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove {source.name}?</AlertDialogTitle>
            <AlertDialogDescription>
              {source.builtIn
                ? "This built-in source can be restored from Settings."
                : "This custom source will be deleted from this device."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep</AlertDialogCancel>
            <AlertDialogAction onClick={() => removeExtension(source.id)}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
