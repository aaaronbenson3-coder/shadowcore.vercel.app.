import { Link, useNavigate } from "@tanstack/react-router";
import { differenceInDays, differenceInHours } from "date-fns";
import {
  ArrowRight,
  Atom,
  BookOpen,
  Calculator,
  Dna,
  FlaskConical,
  Landmark,
  Languages,
  LibraryBig,
  TrendingUp,
} from "lucide-react";
import { Pomodoro } from "@/components/pomodoro";
import { SourceCard } from "@/components/source-card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useHub } from "@/lib/store";
import { SUBJECT_LABEL, SUBJECTS, type Subject } from "@/lib/types";
import { formatDateLabel, todayKey } from "@/lib/utils";

const SUBJECT_TILES: { id: Subject; icon: typeof Calculator }[] = [
  { id: "mathematics", icon: Calculator },
  { id: "english", icon: Languages },
  { id: "physics", icon: Atom },
  { id: "chemistry", icon: FlaskConical },
  { id: "biology", icon: Dna },
  { id: "economics", icon: TrendingUp },
  { id: "government", icon: Landmark },
  { id: "literature", icon: LibraryBig },
];

function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function Countdown({ examDate }: { examDate: string }) {
  const target = new Date(`${examDate}T08:00:00`);
  const now = new Date();
  const days = differenceInDays(target, now);
  const hours = differenceInHours(target, now);
  const year = Number.isNaN(target.getTime()) ? "" : String(target.getFullYear());

  if (Number.isNaN(target.getTime())) {
    return <p className="text-sm text-muted-foreground">Set your exam date in Settings.</p>;
  }

  if (days < 0) {
    return (
      <div>
        <p className="font-display text-4xl font-medium tracking-tight md:text-5xl">Exam season</p>
        <p className="mt-1 text-sm text-muted-foreground">
          WASSCE {year} has started. Keep a steady rhythm, or set the next sitting in Settings.
        </p>
      </div>
    );
  }

  const main = days >= 2 ? days : hours;
  const unit = days >= 2 ? "days" : hours === 1 ? "hour" : "hours";

  return (
    <div>
      <p className="font-display text-5xl font-medium tracking-tight tabular-nums md:text-6xl">
        {main}
        <span className="ml-2 font-sans text-base font-medium text-muted-foreground">{unit}</span>
      </p>
      <p className="mt-1 text-sm text-muted-foreground">until WASSCE {year}</p>
    </div>
  );
}

export function Dashboard() {
  const navigate = useNavigate();
  const extensions = useHub((s) => s.extensions);
  const recentIds = useHub((s) => s.recentIds);
  const tabs = useHub((s) => s.tabs);
  const examDate = useHub((s) => s.examDate);
  const dailyGoalMinutes = useHub((s) => s.dailyGoalMinutes);
  const studiedMinutes = useHub((s) => s.studiedMinutes);
  const studiedDate = useHub((s) => s.studiedDate);
  const logStudyMinutes = useHub((s) => s.logStudyMinutes);
  const hydrated = useHub((s) => s.hydrated);
  const openExtension = useHub((s) => s.openExtension);

  const todayMinutes = studiedDate === todayKey() ? studiedMinutes : 0;
  const goalPct = Math.min(100, Math.round((todayMinutes / dailyGoalMinutes) * 100));

  const byId = new Map(extensions.map((e) => [e.id, e]));
  const recent = recentIds.map((id) => byId.get(id)).filter((e) => e && e.enabled);
  const enabled = extensions.filter((e) => e.enabled);
  const spotlight = (recent.length ? recent : enabled).slice(0, 6);

  function openSubject(subject: Subject) {
    void navigate({ to: "/sources", search: { subject, type: undefined, q: undefined } });
  }

  function resume() {
    if (tabs.length === 0 && enabled[0]) openExtension(enabled[0].id);
    void navigate({ to: "/study" });
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8">
      <header className="stagger-in flex flex-col gap-1">
        <p className="text-sm text-muted-foreground">{formatDateLabel()}</p>
        <h1 className="font-display text-3xl font-medium tracking-tight md:text-4xl">{greeting()}.</h1>
        <p className="max-w-xl text-muted-foreground">
          Stay in one window. Open a source, keep notes beside it, and leave the tab-hopping to everyone else.
        </p>
      </header>

      <section className="grid gap-3 md:grid-cols-5">
        <div className="rounded-2xl bg-card p-5 shadow-[var(--shadow-border)] md:col-span-3">
          <p className="mb-3 text-xs font-medium tracking-wide text-muted-foreground uppercase">
            Countdown
          </p>
          <Countdown examDate={examDate} />
        </div>
        <div className="rounded-2xl bg-card p-5 shadow-[var(--shadow-border)] md:col-span-2">
          <p className="mb-3 text-xs font-medium tracking-wide text-muted-foreground uppercase">
            Today’s goal
          </p>
          <p className="font-display text-3xl font-medium tracking-tight tabular-nums">
            {hydrated ? todayMinutes : 0}
            <span className="ml-1 font-sans text-sm font-medium text-muted-foreground">
              / {dailyGoalMinutes} min
            </span>
          </p>
          <Progress className="mt-4" value={hydrated ? goalPct : 0} />
          <Button variant="ghost" size="sm" className="mt-3 px-0" onClick={() => logStudyMinutes(15)}>
            Log 15 minutes
          </Button>
        </div>
      </section>

      <div className="md:hidden">
        <Pomodoro />
      </div>

      <section>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-xl font-medium">Subjects</h2>
          <Link to="/sources" className="text-sm text-muted-foreground hover:text-foreground">
            All sources
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {SUBJECT_TILES.map((tile) => {
            const Icon = tile.icon;
            return (
              <button
                key={tile.id}
                type="button"
                onClick={() => openSubject(tile.id)}
                className="flex min-h-22 flex-col items-start gap-4 rounded-2xl bg-card p-4 text-left shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
              >
                <span className="flex size-10 items-center justify-center rounded-md bg-accent text-accent-foreground">
                  <Icon className="size-5" />
                </span>
                <span className="text-sm font-medium">{SUBJECT_LABEL[tile.id]}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-xl font-medium">
            {recent.length ? "Continue" : "Ready sources"}
          </h2>
          <Button asChild variant="ghost" size="sm" className="gap-1">
            <Link to="/sources">
              Browse
              <ArrowRight className="size-3.5" />
            </Link>
          </Button>
        </div>
        {spotlight.length === 0 ? (
          <div className="flex flex-col items-start gap-3 rounded-2xl bg-card p-6 shadow-[var(--shadow-border)]">
            <BookOpen className="size-6 text-primary" />
            <p className="font-medium">No sources enabled yet</p>
            <p className="text-sm text-muted-foreground">
              Turn some on from the Sources page, or add your own.
            </p>
            <Button asChild>
              <Link to="/sources">Open sources</Link>
            </Button>
          </div>
        ) : (
          <div className="stagger-in grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {spotlight.map((src) => (src ? <SourceCard key={src.id} source={src} /> : null))}
          </div>
        )}
      </section>

      {enabled[0] || tabs.length > 0 ? (
        <div className="flex justify-center pb-4">
          <Button size="lg" onClick={resume}>
            {tabs.length > 0 ? "Resume study" : "Start studying"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}

export { SUBJECTS };
