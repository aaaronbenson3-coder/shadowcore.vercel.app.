import { SourceIcon } from "@/components/source-icon";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useHub } from "@/lib/store";
import { TYPE_LABEL } from "@/lib/types";

export function SourcePicker({
  open,
  onOpenChange,
  onPick,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPick: (id: string) => void;
}) {
  const extensions = useHub((s) => s.extensions);
  const enabled = [...extensions]
    .filter((e) => e.enabled)
    .sort((a, b) => a.order - b.order || a.name.localeCompare(b.name));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Open a source</DialogTitle>
          <DialogDescription>It loads in a new panel beside your other tabs.</DialogDescription>
        </DialogHeader>
        {enabled.length === 0 ? (
          <p className="text-sm text-muted-foreground">Enable a source on the Sources page first.</p>
        ) : (
          <ScrollArea className="max-h-80">
            <ul className="flex flex-col gap-1 pr-2">
              {enabled.map((src) => (
                <li key={src.id}>
                  <button
                    type="button"
                    className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left hover:bg-muted"
                    onClick={() => {
                      onPick(src.id);
                      onOpenChange(false);
                    }}
                  >
                    <SourceIcon url={src.url} name={src.name} className="size-9" imgClassName="size-5" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{src.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {TYPE_LABEL[src.type]}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}
