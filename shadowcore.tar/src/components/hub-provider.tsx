import { useEffect } from "react";
import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { DEFAULT_EXAM_DATE, mergeMissingBuiltins } from "@/lib/catalog";
import { applyTheme, useHub } from "@/lib/store";

export function HubProvider({ children }: { children: React.ReactNode }) {
  const theme = useHub((s) => s.theme);

  useEffect(() => {
    let cancelled = false;
    void useHub.persist.rehydrate().then(() => {
      if (cancelled) return;
      const s = useHub.getState();
      const examDate = s.examDate === "2026-05-04" ? DEFAULT_EXAM_DATE : s.examDate;
      useHub.setState({
        extensions: mergeMissingBuiltins(s.extensions),
        examDate,
        hydrated: true,
      });
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    applyTheme(theme);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyTheme(useHub.getState().theme);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [theme]);

  useEffect(() => {
    if (!import.meta.env.PROD) return;
    if (!("serviceWorker" in navigator)) return;
    void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  }, []);

  return (
    <TooltipProvider delayDuration={400}>
      {children}
      <Toaster
        position="bottom-right"
        theme={theme === "system" ? "system" : theme}
        toastOptions={{
          className: "font-sans",
        }}
      />
    </TooltipProvider>
  );
}
