import { useNavigate } from "@tanstack/react-router";
import { Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { AddSourceDialog } from "@/components/add-source-dialog";
import { SourceCard } from "@/components/source-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useHub } from "@/lib/store";
import {
  SOURCE_TYPES,
  SUBJECT_LABEL,
  SUBJECTS,
  TYPE_LABEL,
  type SourceType,
  type Subject,
} from "@/lib/types";
import { cn } from "@/lib/utils";

export function SourcesView({
  subject,
  type,
  q,
}: {
  subject?: Subject;
  type?: SourceType;
  q?: string;
}) {
  const navigate = useNavigate();
  const extensions = useHub((s) => s.extensions);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState(q ?? "");

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return [...extensions]
      .sort((a, b) => a.order - b.order)
      .filter((e) => {
        if (subject && subject !== "general" && !e.subjects.includes(subject) && !e.subjects.includes("general")) {
          return false;
        }
        if (subject === "general" && !e.subjects.includes("general")) return false;
        if (type && e.type !== type) return false;
        if (!needle) return true;
        return (
          e.name.toLowerCase().includes(needle) ||
          e.description.toLowerCase().includes(needle) ||
          e.url.toLowerCase().includes(needle)
        );
      });
  }, [extensions, subject, type, query]);

  function setFilter(next: { subject?: Subject; type?: SourceType }) {
    void navigate({
      to: "/sources",
      search: {
        subject: next.subject,
        type: next.type,
        q: query || undefined,
      },
    });
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-medium tracking-tight">Sources</h1>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            Built-in WASCE resources, plus anything you add. Each one opens in the study panel — no extra browser tabs.
          </p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus />
          Add source
        </Button>
      </header>

      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search sources"
          className="pl-9"
          aria-label="Search sources"
        />
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex gap-1.5 overflow-x-auto">
          <FilterChip
            active={!subject}
            onClick={() => setFilter({ subject: undefined, type })}
            label="All subjects"
          />
          {SUBJECTS.map((s) => (
            <FilterChip
              key={s}
              active={subject === s}
              onClick={() => setFilter({ subject: subject === s ? undefined : s, type })}
              label={SUBJECT_LABEL[s]}
            />
          ))}
        </div>
        <div className="flex gap-1.5 overflow-x-auto">
          <FilterChip
            active={!type}
            onClick={() => setFilter({ subject, type: undefined })}
            label="All types"
          />
          {SOURCE_TYPES.map((t) => (
            <FilterChip
              key={t}
              active={type === t}
              onClick={() => setFilter({ subject, type: type === t ? undefined : t })}
              label={TYPE_LABEL[t]}
            />
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl bg-card p-8 text-center shadow-[var(--shadow-border)]">
          <p className="font-medium">No matching sources</p>
          <p className="mt-1 text-sm text-muted-foreground">Try another filter, or add the site yourself.</p>
        </div>
      ) : (
        <div className="stagger-in grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((src) => (
            <SourceCard key={src.id} source={src} />
          ))}
        </div>
      )}

      <AddSourceDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}

function FilterChip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full px-3 text-sm font-medium transition-colors duration-150",
        active ? "bg-primary text-primary-foreground" : "bg-card text-foreground shadow-[var(--shadow-border)]",
      )}
    >
      {label}
    </button>
  );
}
