import { Link, useRouterState } from "@tanstack/react-router";
import { BookMarked, Compass, Home, Library, Settings } from "lucide-react";
import { Wordmark } from "@/components/logo";
import { Pomodoro } from "@/components/pomodoro";
import { SourceIcon } from "@/components/source-icon";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useHub } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/sources", label: "Sources", icon: Compass },
  { to: "/library", label: "Library", icon: Library },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const focusMode = useHub((s) => s.focusMode);
  const tabs = useHub((s) => s.tabs);
  const studying = pathname === "/study";
  const hideSidebar = studying && focusMode;
  const hideBottomNav = studying;

  const extensions = useHub((s) => s.extensions);
  const openExtension = useHub((s) => s.openExtension);
  const pinned = extensions.filter((e) => e.pinned && e.enabled);

  return (
    <div
      className={cn(
        "flex bg-background text-foreground",
        studying ? "h-dvh overflow-hidden" : "min-h-dvh",
      )}
    >
      {!hideSidebar ? (
        <aside className="hidden w-60 shrink-0 flex-col border-r border-sidebar-border bg-sidebar md:flex">
          <div className="px-4 pt-5 pb-4">
            <Link to="/" className="block">
              <Wordmark />
            </Link>
          </div>
          <nav className="flex flex-col gap-0.5 px-2">
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
                    active
                      ? "bg-primary text-primary-foreground"
                      : "text-sidebar-foreground/80 hover:bg-muted hover:text-foreground",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
            <Link
              to="/study"
              className={cn(
                "flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
                studying
                  ? "bg-primary text-primary-foreground"
                  : "text-sidebar-foreground/80 hover:bg-muted hover:text-foreground",
              )}
            >
              <BookMarked className="size-4" />
              Study
              {tabs.length > 0 ? (
                <span className="ml-auto tabular-nums text-xs opacity-80">{tabs.length}</span>
              ) : null}
            </Link>
          </nav>

          <div className="mt-5 px-3">
            <p className="mb-2 px-1 text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Pinned
            </p>
            <ScrollArea className="h-40">
              <div className="flex flex-col gap-0.5">
                {pinned.length === 0 ? (
                  <p className="px-1 text-xs text-muted-foreground">Pin sources to keep them here.</p>
                ) : (
                  pinned.map((src) => (
                    <Link
                      key={src.id}
                      to="/study"
                      onClick={() => openExtension(src.id)}
                      className="flex h-10 items-center gap-2 rounded-md px-2 text-sm hover:bg-muted"
                    >
                      <SourceIcon
                        url={src.url}
                        name={src.name}
                        className="size-5 rounded-sm bg-transparent"
                        imgClassName="size-4"
                      />
                      <span className="truncate">{src.name}</span>
                    </Link>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>

          <div className="mt-auto p-3">
            <Pomodoro />
          </div>
        </aside>
      ) : null}

      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        <main
          className={cn(
            "min-h-0 min-w-0 flex-1",
            studying ? "overflow-hidden p-0" : "px-4 pt-5 pb-24 md:px-8 md:pt-8 md:pb-8",
          )}
        >
          {children}
        </main>

        {!hideBottomNav ? (
          <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur-sm md:hidden">
            <div className="grid grid-cols-4 px-1 pt-1 pb-[max(0.35rem,env(safe-area-inset-bottom))]">
              {NAV.map((item) => {
                const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={cn(
                      "flex min-h-12 flex-col items-center justify-center gap-0.5 text-xs font-medium",
                      active ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    <Icon className="size-5" />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </nav>
        ) : null}
      </div>
    </div>
  );
}
