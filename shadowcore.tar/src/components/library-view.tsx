import { useNavigate } from "@tanstack/react-router";
import { Star, StickyNote, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useHub } from "@/lib/store";
import { hostnameOf } from "@/lib/utils";

export function LibraryView() {
  const navigate = useNavigate();
  const favorites = useHub((s) => s.favorites);
  const notes = useHub((s) => s.notes);
  const removeFavorite = useHub((s) => s.removeFavorite);
  const removeNote = useHub((s) => s.removeNote);
  const setActiveNote = useHub((s) => s.setActiveNote);
  const setNotesPanelOpen = useHub((s) => s.setNotesPanelOpen);
  const openExtension = useHub((s) => s.openExtension);
  const extensions = useHub((s) => s.extensions);

  function openFav(url: string, extensionId?: string) {
    const ext =
      (extensionId && extensions.find((e) => e.id === extensionId)) ||
      extensions.find((e) => e.enabled);
    if (!ext) return;
    openExtension(ext.id, { newTab: true, url });
    void navigate({ to: "/study" });
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8">
      <header>
        <h1 className="font-display text-3xl font-medium tracking-tight">Library</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Saved pages and notes live on this device. Export them from Settings if you want a backup.
        </p>
      </header>

      <section>
        <h2 className="mb-3 font-display text-xl font-medium">Saved pages</h2>
        {favorites.length === 0 ? (
          <Empty
            icon={<Star className="size-5 text-primary" />}
            title="No saved pages"
            body="Star a page from the study toolbar to keep it here."
          />
        ) : (
          <ul className="divide-y divide-border overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
            {favorites.map((f) => (
              <li key={f.id} className="flex items-center gap-3 px-4 py-3">
                <button
                  type="button"
                  className="min-w-0 flex-1 text-left"
                  onClick={() => openFav(f.url, f.extensionId)}
                >
                  <p className="truncate font-medium">{f.title}</p>
                  <p className="truncate text-xs text-muted-foreground">{hostnameOf(f.url)}</p>
                </button>
                <Button
                  size="icon-sm"
                  variant="ghost"
                  aria-label={`Remove ${f.title}`}
                  onClick={() => removeFavorite(f.id)}
                >
                  <Trash2 />
                </Button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="mb-3 font-display text-xl font-medium">Notes</h2>
        {notes.length === 0 ? (
          <Empty
            icon={<StickyNote className="size-5 text-primary" />}
            title="No notes"
            body="Open the notes panel while studying. Everything is saved locally."
          />
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2">
            {notes.map((n) => (
              <li key={n.id} className="flex flex-col rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-medium">{n.title || "Untitled"}</h3>
                  <Button
                    size="icon-sm"
                    variant="ghost"
                    aria-label={`Delete ${n.title}`}
                    onClick={() => removeNote(n.id)}
                  >
                    <Trash2 />
                  </Button>
                </div>
                <p className="mt-2 line-clamp-4 flex-1 text-sm text-muted-foreground">
                  {n.body || "Empty note"}
                </p>
                <Button
                  size="sm"
                  variant="ghost"
                  className="mt-3 self-start px-0"
                  onClick={() => {
                    setActiveNote(n.id);
                    setNotesPanelOpen(true);
                    void navigate({ to: "/study" });
                  }}
                >
                  Open beside study
                </Button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Empty({
  icon,
  title,
  body,
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div className="flex flex-col items-start gap-2 rounded-xl bg-card p-6 shadow-[var(--shadow-border)]">
      {icon}
      <p className="font-medium">{title}</p>
      <p className="text-sm text-muted-foreground">{body}</p>
    </div>
  );
}
