import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { useHub } from "@/lib/store";
import { cn } from "@/lib/utils";

export function NotesPanel() {
  const notes = useHub((s) => s.notes);
  const activeNoteId = useHub((s) => s.activeNoteId);
  const upsertNote = useHub((s) => s.upsertNote);
  const removeNote = useHub((s) => s.removeNote);
  const setActiveNote = useHub((s) => s.setActiveNote);
  const active = notes.find((n) => n.id === activeNoteId) ?? notes[0];

  return (
    <div className="flex h-full min-h-0 flex-col bg-card">
      <div className="flex items-center justify-between border-b border-border px-3 py-2">
        <p className="text-sm font-medium">Notes</p>
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label="New note"
          onClick={() => upsertNote({ title: "New note", body: "" })}
        >
          <Plus />
        </Button>
      </div>
      <div className="flex min-h-0 flex-1">
        <ScrollArea className="w-36 shrink-0 border-r border-border">
          <div className="flex flex-col p-1">
            {notes.length === 0 ? (
              <p className="p-2 text-xs text-muted-foreground">No notes yet.</p>
            ) : (
              notes.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => setActiveNote(n.id)}
                  className={cn(
                    "rounded-md px-2 py-2 text-left text-xs",
                    n.id === active?.id ? "bg-muted font-medium" : "hover:bg-muted/60",
                  )}
                >
                  <span className="line-clamp-2">{n.title || "Untitled"}</span>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
        {active ? (
          <div className="flex min-w-0 flex-1 flex-col gap-2 p-3">
            <div className="flex gap-1">
              <Input
                value={active.title}
                onChange={(e) => upsertNote({ id: active.id, title: e.target.value })}
                className="h-8"
                aria-label="Note title"
              />
              <Button
                size="icon-sm"
                variant="ghost"
                aria-label="Delete note"
                onClick={() => removeNote(active.id)}
              >
                <Trash2 />
              </Button>
            </div>
            <Textarea
              value={active.body}
              onChange={(e) => upsertNote({ id: active.id, body: e.target.value })}
              className="min-h-0 flex-1 resize-none"
              placeholder="Write while you study…"
            />
          </div>
        ) : (
          <div className="flex flex-1 items-center justify-center p-4 text-center text-sm text-muted-foreground">
            Start a note. It stays beside whatever source you open.
          </div>
        )}
      </div>
    </div>
  );
}
