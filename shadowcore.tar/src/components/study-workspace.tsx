import { Link } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  Columns2,
  Compass,
  ExternalLink,
  Home,
  Maximize2,
  Minimize2,
  Pin,
  PinOff,
  Plus,
  RotateCw,
  Star,
  StickyNote,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Group, Panel, Separator as ResizeSeparator } from "react-resizable-panels";
import { toast } from "sonner";
import { NotesPanel } from "@/components/notes-panel";
import { Pomodoro } from "@/components/pomodoro";
import { SourcePicker } from "@/components/source-picker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { IFRAME_ALLOW, IFRAME_SANDBOX, toEmbedUrl } from "@/lib/embed";
import { useHub } from "@/lib/store";
import type { StudyTab } from "@/lib/types";
import { useIsMobile } from "@/lib/use-mobile";
import { cn, ensureHttpUrl, isValidHttpUrl } from "@/lib/utils";

const HINT_KEY = "wasce-hub-embed-hint";

export function StudyWorkspace() {
  const tabs = useHub((s) => s.tabs);
  const activeTabId = useHub((s) => s.activeTabId);
  const splitTabId = useHub((s) => s.splitTabId);
  const notesPanelOpen = useHub((s) => s.notesPanelOpen);
  const focusMode = useHub((s) => s.focusMode);
  const setActiveTab = useHub((s) => s.setActiveTab);
  const closeTab = useHub((s) => s.closeTab);
  const toggleTabPin = useHub((s) => s.toggleTabPin);
  const toggleSplit = useHub((s) => s.toggleSplit);
  const setNotesPanelOpen = useHub((s) => s.setNotesPanelOpen);
  const setFocusMode = useHub((s) => s.setFocusMode);
  const openExtension = useHub((s) => s.openExtension);
  const [picker, setPicker] = useState(false);
  const mobile = useIsMobile();

  const active = tabs.find((t) => t.id === activeTabId) ?? tabs[0];
  const split = splitTabId ? tabs.find((t) => t.id === splitTabId) : undefined;
  const ordered = [...tabs].sort((a, b) => Number(b.pinned) - Number(a.pinned));

  if (tabs.length === 0 || !active) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
        <Compass className="size-8 text-primary" />
        <h1 className="font-display text-2xl font-medium">Nothing open yet</h1>
        <p className="max-w-sm text-sm text-muted-foreground">
          Pick a source from the catalog. It will load here so you can stay in study mode.
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          <Button asChild>
            <Link to="/sources">Browse sources</Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/">Home</Link>
          </Button>
        </div>
      </div>
    );
  }

  const showSplit = Boolean(split && split.id !== active.id && !mobile);

  const browser = (
    <div className="flex min-h-0 min-w-0 flex-1 flex-col">
      {showSplit ? (
        <Group orientation="horizontal" className="min-h-0 flex-1">
          <Panel defaultSize={50} minSize={28} className="min-w-0">
            <FramePane tab={active} />
          </Panel>
          <ResizeSeparator className="w-1 bg-border hover:bg-primary/40" />
          <Panel defaultSize={50} minSize={28} className="min-w-0">
            <FramePane tab={split!} />
          </Panel>
        </Group>
      ) : (
        <FramePane tab={active} />
      )}
    </div>
  );

  return (
    <div className="flex h-full min-h-0 flex-col bg-background">
      <div className="flex items-center gap-1 overflow-x-auto border-b border-border bg-card px-1 pt-1">
        <Link
          to="/"
          className="flex size-9 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground md:hidden"
          aria-label="Home"
        >
          <Home className="size-4" />
        </Link>
        {ordered.map((tab) => {
          const on = tab.id === active.id;
          return (
            <div
              key={tab.id}
              className={cn(
                "group flex h-9 max-w-52 min-w-28 shrink-0 items-center gap-1 rounded-t-md px-2 text-sm",
                on ? "bg-background text-foreground" : "text-muted-foreground hover:bg-muted/80",
              )}
            >
              <button
                type="button"
                className="min-w-0 flex-1 truncate text-left"
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.pinned ? <Pin className="mr-1 inline size-3" /> : null}
                {tab.title}
              </button>
              <button
                type="button"
                className="size-6 rounded-sm hover:bg-muted md:opacity-0 md:group-hover:opacity-100"
                aria-label={`Close ${tab.title}`}
                onClick={() => closeTab(tab.id)}
              >
                <X className="mx-auto size-3.5" />
              </button>
            </div>
          );
        })}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button size="icon-sm" variant="ghost" aria-label="Open another source" onClick={() => setPicker(true)}>
              <Plus />
            </Button>
          </TooltipTrigger>
          <TooltipContent>New panel</TooltipContent>
        </Tooltip>
        <div className="ml-auto flex items-center gap-0.5 pr-1 pb-1">
          <div className="md:hidden">
            <Pomodoro compact />
          </div>
          <IconTip label={active.pinned ? "Unpin tab" : "Pin tab"}>
            <Button size="icon-sm" variant="ghost" onClick={() => toggleTabPin(active.id)}>
              {active.pinned ? <PinOff /> : <Pin />}
            </Button>
          </IconTip>
          <IconTip label={split ? "Exit split" : "Split view"}>
            <Button
              size="icon-sm"
              variant="ghost"
              className="hidden md:inline-flex"
              onClick={() => toggleSplit(active.id)}
            >
              <Columns2 />
            </Button>
          </IconTip>
          <IconTip label="Notes">
            <Button
              size="icon-sm"
              variant={notesPanelOpen ? "secondary" : "ghost"}
              onClick={() => setNotesPanelOpen(!notesPanelOpen)}
            >
              <StickyNote />
            </Button>
          </IconTip>
          <IconTip label={focusMode ? "Show navigation" : "Focus mode"}>
            <Button
              size="icon-sm"
              variant={focusMode ? "secondary" : "ghost"}
              className="hidden md:inline-flex"
              onClick={() => setFocusMode(!focusMode)}
            >
              {focusMode ? <Minimize2 /> : <Maximize2 />}
            </Button>
          </IconTip>
        </div>
      </div>

      {notesPanelOpen && mobile ? (
        <div className="relative min-h-0 flex-1">
          {browser}
          <div className="absolute inset-y-0 right-0 z-20 flex w-[min(100%,20rem)] flex-col border-l border-border bg-card shadow-[var(--shadow-border-hover)]">
            <NotesPanel />
          </div>
        </div>
      ) : notesPanelOpen ? (
        <Group orientation="horizontal" className="min-h-0 flex-1">
          <Panel defaultSize={72} minSize={45} className="min-w-0">
            {browser}
          </Panel>
          <ResizeSeparator className="w-1 bg-border hover:bg-primary/40" />
          <Panel defaultSize={28} minSize={20} className="min-w-0">
            <NotesPanel />
          </Panel>
        </Group>
      ) : (
        browser
      )}

      <SourcePicker
        open={picker}
        onOpenChange={setPicker}
        onPick={(id) => openExtension(id, { newTab: true })}
      />
    </div>
  );
}

function IconTip({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}

function FramePane({ tab }: { tab: StudyTab }) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [address, setAddress] = useState(tab.url);
  const [loading, setLoading] = useState(true);
  const [full, setFull] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const updateTab = useHub((s) => s.updateTab);
  const addFavorite = useHub((s) => s.addFavorite);
  const favorites = useHub((s) => s.favorites);
  const starred = favorites.some((f) => f.url === tab.url);

  useEffect(() => {
    setAddress(tab.url);
    setLoading(true);
  }, [tab.url, tab.id]);

  useEffect(() => {
    try {
      if (!localStorage.getItem(HINT_KEY)) {
        toast.message("If a page looks blank, the site may block in-app viewing. Use Open outside.");
        localStorage.setItem(HINT_KEY, "1");
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    function onFs() {
      setFull(document.fullscreenElement === wrapRef.current);
    }
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  function go(raw: string) {
    if (!isValidHttpUrl(raw)) {
      toast.error("Enter a full URL, starting with https://");
      return;
    }
    const next = toEmbedUrl(ensureHttpUrl(raw));
    updateTab(tab.id, { url: next });
  }

  function historyNav(dir: 1 | -1) {
    try {
      iframeRef.current?.contentWindow?.history.go(dir);
    } catch {
      toast.message("This site does not allow in-app history.");
    }
  }

  function reload() {
    setLoading(true);
    const el = iframeRef.current;
    if (el) el.src = el.src;
  }

  function toggleFull() {
    const node = wrapRef.current;
    if (!node) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void node.requestFullscreen();
  }

  return (
    <div ref={wrapRef} className="flex h-full min-h-0 flex-col bg-background">
      <div className="flex items-center gap-1 border-b border-border bg-card px-2 py-1.5">
        <Button size="icon-sm" variant="ghost" aria-label="Back" onClick={() => historyNav(-1)}>
          <ArrowLeft />
        </Button>
        <Button size="icon-sm" variant="ghost" aria-label="Forward" onClick={() => historyNav(1)}>
          <ArrowRight />
        </Button>
        <Button size="icon-sm" variant="ghost" aria-label="Reload" onClick={reload}>
          <RotateCw className={cn(loading && "animate-spin")} />
        </Button>
        <form
          className="min-w-0 flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            go(address);
          }}
        >
          <Input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="h-8 font-mono text-xs"
            aria-label="Address"
          />
        </form>
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label={starred ? "Saved" : "Save page"}
          onClick={() => {
            addFavorite({ title: tab.title, url: tab.url, extensionId: tab.extensionId });
            toast.success("Saved to Library");
          }}
        >
          <Star className={cn(starred && "fill-primary text-primary")} />
        </Button>
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label="Open outside if this page is blank"
          title="Open outside — use this if the page is blank"
          onClick={() => window.open(tab.url, "_blank", "noopener")}
        >
          <ExternalLink />
        </Button>
        <Button size="icon-sm" variant="ghost" aria-label="Full screen" onClick={toggleFull}>
          {full ? <Minimize2 /> : <Maximize2 />}
        </Button>
      </div>

      <div className="relative min-h-0 flex-1 bg-muted">
        {loading ? (
          <div className="absolute inset-x-0 top-0 z-10 h-0.5 overflow-hidden">
            <div className="h-full w-1/3 animate-pulse bg-primary" />
          </div>
        ) : null}
        <iframe
          ref={iframeRef}
          title={tab.title}
          src={tab.url}
          className="size-full border-0 bg-card"
          sandbox={IFRAME_SANDBOX}
          allow={IFRAME_ALLOW}
          referrerPolicy="no-referrer-when-downgrade"
          onLoad={() => setLoading(false)}
        />
      </div>
    </div>
  );
}
