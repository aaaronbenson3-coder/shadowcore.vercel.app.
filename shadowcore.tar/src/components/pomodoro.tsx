import { Pause, Play, RotateCcw, Timer } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { useHub } from "@/lib/store";
import { cn } from "@/lib/utils";

type Phase = "focus" | "break";

export function Pomodoro({ compact = false }: { compact?: boolean }) {
  const workMin = useHub((s) => s.pomodoroMinutes);
  const breakMin = useHub((s) => s.breakMinutes);
  const logStudyMinutes = useHub((s) => s.logStudyMinutes);

  const [phase, setPhase] = useState<Phase>("focus");
  const [remaining, setRemaining] = useState(workMin * 60);
  const [running, setRunning] = useState(false);
  const tick = useRef<number | null>(null);

  useEffect(() => {
    if (!running) {
      if (phase === "focus") setRemaining(workMin * 60);
      else setRemaining(breakMin * 60);
    }
  }, [workMin, breakMin, phase, running]);

  useEffect(() => {
    if (!running) return;
    tick.current = window.setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          window.clearInterval(tick.current ?? 0);
          setRunning(false);
          if (phase === "focus") {
            logStudyMinutes(workMin);
            setPhase("break");
            return breakMin * 60;
          }
          setPhase("focus");
          return workMin * 60;
        }
        return r - 1;
      });
    }, 1000);
    return () => {
      if (tick.current) window.clearInterval(tick.current);
    };
  }, [running, phase, workMin, breakMin, logStudyMinutes]);

  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");
  const total = (phase === "focus" ? workMin : breakMin) * 60;
  const pct = total > 0 ? (1 - remaining / total) * 100 : 0;

  function reset() {
    setRunning(false);
    setPhase("focus");
    setRemaining(workMin * 60);
  }

  if (compact) {
    return (
      <button
        type="button"
        onClick={() => setRunning((v) => !v)}
        className="flex shrink-0 items-center gap-2 rounded-lg px-2 py-1.5 text-left hover:bg-muted/70"
        aria-label={running ? "Pause timer" : "Start timer"}
      >
        <Timer className="size-4 text-primary" />
        <span className="font-medium tabular-nums">
          {mm}:{ss}
        </span>
        <span className="text-xs text-muted-foreground uppercase">{phase}</span>
      </button>
    );
  }

  return (
    <div className="rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          {phase === "focus" ? "Focus" : "Break"}
        </span>
        <span className="font-display text-2xl tracking-tight tabular-nums">
          {mm}:{ss}
        </span>
      </div>
      <div className="mb-3 h-1.5 overflow-hidden rounded-full bg-muted">
        <div
          className={cn("h-full rounded-full bg-primary transition-[width] duration-1000 ease-linear")}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex gap-1.5">
        <Button
          size="sm"
          variant={running ? "secondary" : "default"}
          className="flex-1"
          onClick={() => setRunning((v) => !v)}
        >
          {running ? <Pause /> : <Play />}
          {running ? "Pause" : "Start"}
        </Button>
        <Button size="icon-sm" variant="ghost" onClick={reset} aria-label="Reset timer">
          <RotateCcw />
        </Button>
      </div>
    </div>
  );
}
