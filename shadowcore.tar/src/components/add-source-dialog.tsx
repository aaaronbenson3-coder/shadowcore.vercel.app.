import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useHub } from "@/lib/store";
import { SOURCE_TYPES, SUBJECTS, TYPE_LABEL, type SourceType, type Subject } from "@/lib/types";
import { ensureHttpUrl, isValidHttpUrl } from "@/lib/utils";

export function AddSourceDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const addExtension = useHub((s) => s.addExtension);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<SourceType>("notes");
  const [subject, setSubject] = useState<Subject>("general");

  function reset() {
    setName("");
    setUrl("");
    setDescription("");
    setType("notes");
    setSubject("general");
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !isValidHttpUrl(url)) {
      toast.error("Enter a name and a valid https URL.");
      return;
    }
    addExtension({
      name,
      url: ensureHttpUrl(url),
      description,
      type,
      subjects: [subject],
    });
    toast.success(`Added ${name.trim()}`);
    reset();
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add a source</DialogTitle>
          <DialogDescription>
            Any study site, playlist, PDF library, or deep link. It opens inside WASCE Hub.
          </DialogDescription>
        </DialogHeader>
        <form className="grid gap-3" onSubmit={submit}>
          <div className="grid gap-1.5">
            <Label htmlFor="src-name">Name</Label>
            <Input
              id="src-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="English Paper 2 notes"
              required
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="src-url">URL</Label>
            <Input
              id="src-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://"
              inputMode="url"
              required
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="src-desc">Short description</Label>
            <Textarea
              id="src-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="What will you study here?"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label>Type</Label>
              <Select value={type} onValueChange={(v) => setType(v as SourceType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SOURCE_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {TYPE_LABEL[t]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label>Subject</Label>
              <Select value={subject} onValueChange={(v) => setSubject(v as Subject)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUBJECTS.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s[0]!.toUpperCase() + s.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-1 flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Add source</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
