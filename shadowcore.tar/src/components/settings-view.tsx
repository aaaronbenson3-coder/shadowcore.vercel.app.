import { Download, Moon, Sun, Upload } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useHub } from "@/lib/store";
import type { HubExport, ThemeMode } from "@/lib/types";

export function SettingsView() {
  const theme = useHub((s) => s.theme);
  const examDate = useHub((s) => s.examDate);
  const dailyGoalMinutes = useHub((s) => s.dailyGoalMinutes);
  const pomodoroMinutes = useHub((s) => s.pomodoroMinutes);
  const breakMinutes = useHub((s) => s.breakMinutes);
  const setTheme = useHub((s) => s.setTheme);
  const setExamDate = useHub((s) => s.setExamDate);
  const setDailyGoal = useHub((s) => s.setDailyGoal);
  const setPomodoroMinutes = useHub((s) => s.setPomodoroMinutes);
  const setBreakMinutes = useHub((s) => s.setBreakMinutes);
  const restoreCatalog = useHub((s) => s.restoreCatalog);
  const exportData = useHub((s) => s.exportData);
  const importData = useHub((s) => s.importData);
  const fileRef = useRef<HTMLInputElement>(null);

  function download() {
    const blob = new Blob([JSON.stringify(exportData(), null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "wasce-hub-setup.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Setup exported");
  }

  function onImport(file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result)) as HubExport;
        importData(data);
        toast.success("Setup imported");
      } catch {
        toast.error("That file is not a WASCE Hub export.");
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-8">
      <header>
        <h1 className="font-display text-3xl font-medium tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Preferences stay on this device. Nothing is sent to a server.
        </p>
      </header>

      <section className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <h2 className="font-display text-lg font-medium">Appearance</h2>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {(
            [
              { id: "light", label: "Light", icon: Sun },
              { id: "dark", label: "Dark", icon: Moon },
              { id: "system", label: "System", icon: Sun },
            ] as const
          ).map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setTheme(opt.id as ThemeMode)}
              className={`flex h-20 flex-col items-center justify-center gap-1 rounded-lg text-sm font-medium ${
                theme === opt.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/60 text-foreground hover:bg-muted"
              }`}
            >
              <opt.icon className="size-4" />
              {opt.label}
            </button>
          ))}
        </div>
      </section>

      <section className="grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <h2 className="font-display text-lg font-medium">Exam & study</h2>
        <div className="grid gap-1.5">
          <Label htmlFor="exam-date">WASSCE date</Label>
          <Input
            id="exam-date"
            type="date"
            value={examDate}
            onChange={(e) => setExamDate(e.target.value)}
          />
          <p className="text-xs text-muted-foreground">
            Used for the home countdown. Change the year when the timetable is published.
          </p>
        </div>
        <div className="grid gap-1.5">
          <Label>Daily goal</Label>
          <Select
            value={String(dailyGoalMinutes)}
            onValueChange={(v) => setDailyGoal(Number(v))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[30, 45, 60, 90, 120, 180].map((n) => (
                <SelectItem key={n} value={String(n)}>
                  {n} minutes
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-1.5">
            <Label>Focus length</Label>
            <Select
              value={String(pomodoroMinutes)}
              onValueChange={(v) => setPomodoroMinutes(Number(v))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[15, 20, 25, 40, 50].map((n) => (
                  <SelectItem key={n} value={String(n)}>
                    {n} min
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label>Break length</Label>
            <Select value={String(breakMinutes)} onValueChange={(v) => setBreakMinutes(Number(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[5, 10, 15].map((n) => (
                  <SelectItem key={n} value={String(n)}>
                    {n} min
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      <section className="grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <h2 className="font-display text-lg font-medium">Sources</h2>
        <p className="text-sm text-muted-foreground">
          Share your setup with a classmate, or restore the original WASCE catalog.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={download}>
            <Download /> Export JSON
          </Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()}>
            <Upload /> Import JSON
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              restoreCatalog();
              toast.success("Built-in catalog restored");
            }}
          >
            Restore catalog
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => onImport(e.target.files?.[0])}
          />
        </div>
      </section>

      <section className="grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <h2 className="font-display text-lg font-medium">Install as an app</h2>
        <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
          <li>Open this page in Chrome, Edge, or Safari.</li>
          <li>
            On a phone: use the browser menu, then <span className="text-foreground">Add to Home Screen</span>.
          </li>
          <li>
            On a computer: look for the install icon in the address bar, or the browser menu item
            <span className="text-foreground"> Install WASCE Hub</span>.
          </li>
        </ol>
        <p className="text-sm text-muted-foreground">
          The interface works offline. Source websites still need a connection.
        </p>
      </section>

      <section className="rounded-xl bg-card p-5 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
        <h2 className="font-display text-lg font-medium text-foreground">Add more sources</h2>
        <p className="mt-2">
          Use Sources → Add source for any website. For a shared default list, a developer can append objects
          to the catalog in the app source — each needs a name, URL, type, and subjects.
        </p>
      </section>
    </div>
  );
}
