import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8", className)} aria-hidden>
      <rect width="32" height="32" rx="8" className="fill-primary" />
      <path
        d="M8 11.5h3.2l2.15 6.4 2.2-6.4h3.05l2.2 6.4 2.15-6.4H26L21.4 22h-3.15L16.1 15.9 14 22H10.8L8 11.5Z"
        className="fill-primary-foreground"
      />
      <path
        d="M9 24.2h14"
        className="stroke-primary-foreground"
        strokeWidth="1.4"
        strokeLinecap="round"
        opacity="0.55"
      />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <LogoMark className="size-8 shrink-0" />
      {!compact ? (
        <div className="min-w-0 leading-tight">
          <div className="font-display text-[15px] font-semibold tracking-tight text-foreground">
            WASCE Hub
          </div>
          <div className="text-[11px] tracking-wide text-muted-foreground uppercase">
            Study mode
          </div>
        </div>
      ) : null}
    </div>
  );
}
