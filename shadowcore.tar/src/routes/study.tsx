import { createFileRoute } from "@tanstack/react-router";
import { StudyWorkspace } from "@/components/study-workspace";

export const Route = createFileRoute("/study")({ component: StudyPage });

function StudyPage() {
  return <StudyWorkspace />;
}
