import { createFileRoute } from "@tanstack/react-router";
import { SourcesView } from "@/components/sources-view";
import { SOURCE_TYPES, SUBJECTS, type SourceType, type Subject } from "@/lib/types";

type SourcesSearch = {
  q?: string;
  subject?: Subject;
  type?: SourceType;
};

export const Route = createFileRoute("/sources")({
  validateSearch: (search: Record<string, unknown>): SourcesSearch => ({
    q: typeof search.q === "string" ? search.q : undefined,
    subject: SUBJECTS.includes(search.subject as Subject) ? (search.subject as Subject) : undefined,
    type: SOURCE_TYPES.includes(search.type as SourceType) ? (search.type as SourceType) : undefined,
  }),
  component: SourcesPage,
});

function SourcesPage() {
  const { subject, type, q } = Route.useSearch();
  return <SourcesView subject={subject} type={type} q={q} />;
}
